import java.io.*;
import java.util.Scanner;
class exp71
{
	
  public static void main(String args[])throws IOException
  {
	   try
	   {
		   String s="";
		   String content;
		   String ch = "Y";
	    Scanner sc=new Scanner(System.in);
	    System.out.println("Enter file name");	
	    s=sc.nextLine();
	    File f=new File(s);
		if(f.exists())
		{
			System.out.println("File is present");
			System.out.println ("Do you want to append data into it.(Y/N)");
			ch = sc.nextLine();
			
			if (ch.equals("Y")||ch.equals("y"))
				{
				  int i;
			      FileInputStream fin=new FileInputStream(s);
				  
	              while((i=fin.read())!=-1)
	              {

		            System.out.print((char)i);
	  	          }
				  FileOutputStream fout=new FileOutputStream(s,true);	
				  System.out.println("\n enter data on file");
				  content = sc.nextLine();
				  byte b[]=content.getBytes();
				  fout.write(b);
				  System.out.println ("Data Appended into file.");
				  
			
				  fout.flush();
	             fin.close();
				  
				  /*FileOutputStream fout=new FileOutputStream(s);	
		          System.out.println("enter data on file");
				  content = sc.nextLine();
				  byte b[]=content.getBytes();
				  fout.write(b);
				  System.out.println ("Data Appended into file.");
				  fout.flush();
	              fout.close();*/
                }				
			
			/*int i;
			FileInputStream fin=new FileInputStream(s);
	      while((i=fin.read())!=-1)
	     {
		    System.out.print((char)i);
	  	 }*/
	 // fin.close();
		}	
		else
		{
		  FileOutputStream fout=new FileOutputStream(s);	
		  System.out.println("enter data on file");
		  content = sc.nextLine();
		  byte b[]=content.getBytes();
	      fout.write(b);
	      fout.close();
	    }		
	   }
	   catch(Exception e)
	   {
		   System.out.println(e);
	   }	   
  
  }  
}	
	