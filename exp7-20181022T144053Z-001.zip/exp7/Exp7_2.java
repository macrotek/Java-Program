
/*Write a program to remove white spaces from a text file. Name of the file is given using
Command line.*/

import java.io.*;
import java.util.*;

class Exp7_2
{
	public static void main(String arg[]) 
	{
		try
		{
			String s="",s1="",s3="",ch="";
			
			byte b[];
			int i,cnt=0;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter The File Name:");
			s=sc.nextLine();
			
			File f = new File(s);
			if(f.exists())
				{
					FileInputStream fin=new FileInputStream(s);
					System.out.println("\n Data Written On The File Is:");
					System.out.println("\n---------------------------------- ");
					while((i=fin.read())!=-1)
					{
						if(i==32)
						{
							cnt++;
							continue;
						}
						System.out.print((char)i);
					}
					System.out.println("\n White Spaces Are: "+cnt);
					System.out.println("\n---------------------------------- ");
				}
			else
			{
				FileOutputStream fout = new FileOutputStream(s,true);
					System.out.println("\n The File Name You Entered Is Not Present!!");
					System.out.println("\n---------------------------------- ");
					System.out.println("\n Enter The Data: ");
					s1=sc.nextLine();
					 b=s1.getBytes();
					fout.write(b);
				
			}
		}
		catch(Exception e)
		{
		System.out.println(e);
		}
	}
}