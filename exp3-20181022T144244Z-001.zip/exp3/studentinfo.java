import java.util.Scanner;
class student
{
	int rollno;
	String name;
	Scanner sc=new Scanner(System.in);
	void get()
	{

	System.out.println("Enter the rollno=");
	rollno=sc.nextInt();
	
	System.out.println("Enter the name=");
	name=sc.next();
	
	}
}

class stud extends student
{
	 
	void display()
	{
	System.out.println("name="+name);
	System.out.println("rollno="+rollno);
	
	}
}

class marks extends student
{
	int m1,m2,m3,m4,m5;
	int total;
	double avg;
	Scanner sc=new Scanner(System.in);
	void accept()
	{
	
	System.out.println("Enter the five subject marks=");
	m1=sc.nextInt();
	m2=sc.nextInt();
	m3=sc.nextInt();
	m4=sc.nextInt();
	m5=sc.nextInt();
	}
	   void display1()
	    {
		total=m1+m2+m3+m4+m5;
		avg=total/5;
		System.out.println("total="+total);
		System.out.println("average="+avg);
		}
	
}



class studentinfo
{
public static void main(String args[])
	{
	marks m=new marks();
	stud s1=new stud();
	
	s1.get();
	m.accept();
	s1.display();
	m.display1();
	}	
}
