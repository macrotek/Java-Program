import java.util.Scanner;

class Number
{

	int num1,num2;
	Scanner sc=new Scanner(System.in);

	void get()
	{

	System.out.println("Enter two numbers\n");
	num1=sc.nextInt();
	num2=sc.nextInt();
	
	}

}

class Addition extends Number
{

	int add;

//	void add1();
	
	{

	add=num1+num2;

	System.out.println("Addition is="+add);

	}


}

class Subtraction extends addition
{
	int sub;
//	void sub1()
	{

	sub=num1-num2;

	System.out.println("Subtraction is="+sub);

	}


}

class Multiplication extends Subtraction
{
	int mul;	
//	void mul1()
	{

	mul=num1*num2;
	
	System.out.println("Multiplication is="+mul);

	}

}

class Mathemathics
{

	public static void main(String [] args)
	{

	int ch;

	Scanner sc=new Scanner(System.in);
	
	Multiplication m=new Multiplication();
	m.get();

	do
	{

	System.out.println("Enter your choice\n1.Addition\n2.Subtraction\n3.Multiplication\n4.Exit\n");

	ch=sc.nextInt();
	
	switch(ch)
	{

	case 1: m.add1();
		break;

	case 2: m.sub1();
		break;


	case 3: m.mul1();
		break;


	}

	}while(ch!=4);	

	}



}


