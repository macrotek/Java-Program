import java.util.Scanner;
class number
{
	int num1,num2;
	Scanner sc=new Scanner(System.in);
	void get()
	{
    System.out.println("Enter two number=");
	num1=sc.nextInt();
	num2=sc.nextInt();
	}
			
}

class addition extends number
{
  int add;
  
  void add1()
  {
	  add=num1+num2;
	  System.out.println("addition="+add);
  }
}

class subtraction extends addition
{
	int sub;
	
	void sub1()
	{
		 sub=num1-num2;
	  System.out.println("subtraction is="+sub);
	}
  
}

class multiplication extends subtraction
{
	int mul;
	
	void mul1()
	{
		mul=num1*num2;
	  System.out.println("multiplication is="+mul);
	}
  
}

class mathematical
{
  public static void main(String args[])
  {
	  Scanner sc=new Scanner(System.in);
    multiplication m=new multiplication();
	m.get();
	int ch;
	
	do
	{
		System.out.println("1.Addition\n 2.Subtraction\n 3.Multiplication\n 4.exit\n");
		System.out.println("enter your choice=");
		ch=sc.nextInt();
		
		switch(ch)
		{
			case 1:
			m.add1();
			break;
			
			case 2:
			m.sub1();
			break;
			
			case 3:
			m.mul1();
			break;
		}	
			
	}while(ch!=4);
	
  }
}
