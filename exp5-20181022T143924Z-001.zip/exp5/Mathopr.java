package math;
import java.util.Scanner;
public class Mathopr
{
	int num1,num2,num3,result,cnt,no1,no2,no3,sum,mean1;
	float mean,median;
	Scanner sc=new Scanner(System.in);
	public void mean()
	{
		System.out.println("enter three number");
		no1=sc.nextInt();
		no2=sc.nextInt();
		no3=sc.nextInt();
		
		sum=no1+no2+no3;
		mean1=sum/2;
		System.out.println("mean result="+mean1);
	}
	public void median()
	{
		
		
	}
	public void avg()
	{
		System.out.println("\n Enter 3 Numbers:");
		num1=sc.nextInt();
		num2=sc.nextInt();
		num3=sc.nextInt();
		result=num1+num2+num3;
		result=result/3;
		System.out.println("\n The Average Is: "+result);
	}
	public void std_derivation()
	{
		
	}
}
