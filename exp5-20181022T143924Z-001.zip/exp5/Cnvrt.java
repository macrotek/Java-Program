package math.conver;
import java.util.Scanner;g

public class Cnvrt
{	
	int d,i;
	int [] rem=new int[5];
	float o,b,hex;
	Scanner sc=new Scanner(System.in);
	public void dec_to_oct()
	{
		System.out.println("\n Enter The Decimal Number:");
		d=sc.nextInt();
		rem[0]=d/8;
		rem[1]=d%8;
		System.out.println("Octal No:"+rem[0]+""+rem[1]);
	}
	public void dec_to_bin()
	{
		System.out.println("\n Enter The Decimal Number:  ");
		d=sc.nextInt();
		i=0;
		do
		{
			rem[i]=d%2; 
			d=d/2;
			i++;
			
		}while(d>0);
		System.out.println("\n");
		for(i=3;i>=0;i--)
		{
			System.out.print(" "+rem[i]);
		}
	}
	public void dec_to_hex()
	{
		System.out.println("\n Enter The Decimal Number:");
		d=sc.nextInt();
		rem[0]=d/16;
		rem[1]=d%16;
		System.out.println("Hex No:"+rem[0]+""+rem[1]);
	}
}
