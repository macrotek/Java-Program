package math;
import math.Mathopr;
import math.conver.Cnvrt;
import java.util.Scanner;

class Exp5
{
	public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		Mathopr m=new Mathopr();
		System.out.println("\n Main Prog");
		Cnvrt c=new Cnvrt();
		int ch;
		ch=sc.nextInt();
		switch(ch)
		{
			case 1:
				c.dec_to_oct();
			break;
			
			case 2:
				c.dec_to_bin();
			break;
			
			case 3:
				c.dec_to_hex();
				break;
		}
		m.mean();
		//m.median();
		m.avg();
		//m.std_derivation();
		
		

		
		
	}
}
