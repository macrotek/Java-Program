
Roll No:-329
Batch:-T2
Experiment No:-13
ServerSide
import java.net.*;
import java.io.*;
class ServerSide
{
 public static void main(String ar[])
 {
  try
  {
	ServerSocket ss=new ServerSocket(6666);
     
     Socket s =ss.accept();
     
   
     DataInputStream dis=new DataInputStream(s.getInputStream());
		
      String str=(String)dis.readUTF();
     
     System.out.println("Message= "+str);
     
     ss.close();
     
   }
   catch(Exception e){}  

}
}

client slide
import java.net.*;
import java.io.*;

class ClientSide
{

 public static void main(String ar[])
 {
  try
  {
	  Socket s=new Socket("localhost",6666);
	  
	  DataOutputStream dout=new DataOutputStream(s.getOutputStream());

     dout.writeUTF("Hi server....");
   
		dout.flush();
		dout.close();
		s.close();
   }
   catch(Exception e){}
  }
 }  

 
 


