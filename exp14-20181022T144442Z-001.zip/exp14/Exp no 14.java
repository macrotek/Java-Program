Experiment no: 14 				Roll no: 332
Problem statement-
Write a GUI based program to store and retrieve, delete and update Student�s information in
Database
Program-
import java.sql.*;

public class MsAccessDatabaseConnectionExample {

	public static void main(String[] args) {

		// variables
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;

		// Step 1: Loading or registering Oracle JDBC driver class
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		}
		catch(ClassNotFoundException cnfex) {
			
			System.out.println("Problem in loading MS Access JDBC driver");
			
		}

		// Step 2: Opening database connection
		try {

			String msAccessDBName ="D:\\123\\term end\\exp14\\db1.mdb";
			
			String dbURL = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};                                   
			DBQ=" + msAccessDBName + ";DriverID=22;READONLY=true";

			// Step 2.A: Create and get connection using DriverManager class
			connection = DriverManager.getConnection(dbURL); 

			// Step 2.B: Creating JDBC Statement 
			statement = connection.createStatement();

			// Step 2.C: Executing SELECT stmt to  retrieve data into ResultSet
			resultSet = statement.executeQuery("SELECT * FROM Table1");

			System.out.println("\t Roll No \t Name\t\t Class");
			System.out.println("\t=========\t======\t\t=======");

			// processing returned data and printing into console
			while(resultSet.next()) {
				System.out.println("\t" + 
						resultSet.getString(1) + "\t\t" + 
						resultSet.getString(2) + "\t\t" +
						resultSet.getString(3));
			}

		}
		catch(SQLException sqlex){
			sqlex.printStackTrace();
		}
		finally {

			// Step 3: Closing database connection
			try {
				if(null != connection) {

					// cleanup resources, once after processing
					resultSet.close();
					statement.close();

					// and then finally close connection
					connection.close();
				}
			}
			catch (SQLException sqlex) {
				sqlex.printStackTrace();
			}
		}
	}
}

