import javax.swing.*;
import java.awt.Color;
import javax.swing.JFrame;
class GUIdemo3 extends JFrame
{
   GUIdemo3()
   {
	   
      JLabel l1=new JLabel("Name :");
	  l1.setBounds(100,100,100,40);
	  add(l1);
	  
	  JLabel l2=new JLabel("Address :");
	  l2.setBounds(100,150,100,40);
	  add(l2);
	  
	  JLabel l3=new JLabel("Contact No :");
	  l3.setBounds(100,200,100,40);
	  add(l3);
	  
	  JTextField t1=new JTextField(10);
	  t1.setBounds(200,100,100,40);
	  add(t1);
	  
	  JTextField t2=new JTextField(10);
	  t2.setBounds(200,150,100,40);
	  add(t2);
	  
	  JTextField t3=new JTextField(10);
	  t3.setBounds(200,200,100,40);
	  add(t3);
	  
      JButton b=new JButton("Submit");
	   b.setBackground(Color.RED);
	  b.setBounds(200,250,100,40);
	  add(b);
	  
	  JButton b1=new JButton("Edit");
	  b1.setBounds(320,250,100,40);
	  add(b1);
	  
	  JButton b2=new JButton("Cancel");
	  b2.setBackground(Color.RED);
	  b2.setBounds(440,250,100,40);
	  add(b2);
	  
	  getContentPane().setBackground( Color.WHITE);
	  setSize(600,700);
	  setLayout(null);
	  setVisible(true);
   }
public static void main(String args[]) 
{
   	new  GUIdemo3();
}
}	
  	